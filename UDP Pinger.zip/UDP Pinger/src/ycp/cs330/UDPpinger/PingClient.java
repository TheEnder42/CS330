package ycp.cs330.UDPpinger;

import java.net.*;

public class PingClient {
	
	public static void main(String[] args) throws Exception{
		
		String serverHostName = "localhost";
		
		InetAddress serverIPAddress = null;
		
		int serverPortNumber = 5000;
		
		DatagramSocket clientSocket = new DatagramSocket(Integer.parseInt(args[0]));
		
		serverIPAddress = InetAddress.getByName(serverHostName);
		
		String message = "Ping! sent by " + InetAddress.getLocalHost();
		
		byte[] sendData = new byte[message.length() * 8];
		sendData = message.getBytes();
		
		DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverIPAddress, serverPortNumber);
		DatagramPacket replyPkt = new DatagramPacket(new byte[1024], 1024);
		
		//stat vars
		long[] rtt = new long[15]; 
		long timeStart, timeEnd;
		long min, max, avg = 0, lost = 0, replies = 0;
		
		for(int i=0; i<15; i++){
			timeStart = System.currentTimeMillis();
			clientSocket.send(sendPacket);
			
			clientSocket.setSoTimeout(2000); //2000ms = 2seconds
			
			try{
				clientSocket.receive(replyPkt);
				timeEnd = System.currentTimeMillis();
				rtt[i] = timeEnd - timeStart;
				replies++;
				System.out.println("Recieved PING " + i);
			}
			catch (SocketTimeoutException e){
				//track ping lost
				rtt[i] = -1;
				lost++;
				//System.out.println("FAILED PING " + i);
			}
			
		}
		System.out.println("------------------------------------");
		min = max = rtt[0];
		for(int i=0; i<15; i++){
			System.out.print("PING " + i);
			if(rtt[i] >= 0){
				System.out.println(": RTT = " + rtt[i]);
				if(rtt[i] > max){
					max = rtt[i];
				}
				else if(rtt[i] < min && rtt[i] != -1){
					min = rtt[i];
				}
				avg += rtt[i];
			}
			else{
				System.out.println("  was lost.");
			}
		}
		
		System.out.println("------------------------------------");
		
		System.out.println("Min RTT: " + min + "   Max RTT: " + max + "   Avg RTT: " + avg/replies);
		System.out.println(replies + " Replies, " + lost + " Lost");
		
		clientSocket.close();
		
	}
	
	
}
